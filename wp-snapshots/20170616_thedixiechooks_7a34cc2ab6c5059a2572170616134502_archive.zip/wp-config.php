<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'dixiechooks');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', 'astraybay');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '9<0arobAB|0-L/hd4L`AQ<f![N=t(AB&a[+O@6hRuGTj6qC 4Yc|B}4*@!j&Eed@');
define('SECURE_AUTH_KEY',  'FOj%@a]<fiS492hp$X1f+v P#.j,uD:<A4[tyxNjD2Da+nE5f5O=hv&gp9u+M`@[');
define('LOGGED_IN_KEY',    '}CWEt,iF2MoA=KY4j>pgmb+qiWklfS@KdU Af)u`ewtbJ*~#ggQ-u*i93Jr2U$87');
define('NONCE_KEY',        'c2q7bL8wZOz[n,-2_L~A$ZggvFAW=]DX]x*D7QQr|,J523x!(>!Mp:@1;q)6Ar2p');
define('AUTH_SALT',        '5BUL!-Sx:QgOINBTY4^%)?(3U9Oo$AVm|tT`9x^`L*G&{2i1LJ2swVUH5#D8Ce?a');
define('SECURE_AUTH_SALT', 'yu-s?*_P-jbX eCJQby~FBeg,u@2OHnZOdMU4:@`JMt {NUa[~>]c:Ya^8YTm_t&');
define('LOGGED_IN_SALT',   '6CDN=i_YTe~}b&q~4h0(Y0Bmo9^SC!]@e#ZlF$Ezyt8fZQS@*w&i-dX`#7LH!zKm');
define('NONCE_SALT',       'vw:s|Ga.#eGVm1~gTZR;MH?{qMD0)<IG<x6kbDA2[&W(+p3&PUw>B8zqut*=l9H_');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
